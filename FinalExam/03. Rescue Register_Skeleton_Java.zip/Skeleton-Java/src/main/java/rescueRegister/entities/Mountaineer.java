package rescueRegister.entities;

import javax.persistence.*;

@Entity
@Table(name = "mountaineers")
public class Mountaineer {
    //TODO
}
