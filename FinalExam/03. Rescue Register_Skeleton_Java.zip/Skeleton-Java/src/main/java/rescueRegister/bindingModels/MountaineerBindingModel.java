package rescueRegister.bindingModels;

public class MountaineerBindingModel {
    //TODO
}
